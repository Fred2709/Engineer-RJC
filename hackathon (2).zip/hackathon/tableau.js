document.addEventListener("DOMContentLoaded", function () {
    const applyButton = document.querySelector(".apply-button");
    const cuisineButtons = document.querySelectorAll("[data-filter-group='cuisine']");
    const ratingButtons = document.querySelectorAll("[data-filter-group='rating']");
    const hoursButtons = document.querySelectorAll("[data-filter-group='hours']");
    const sortButtons = document.querySelectorAll("[data-filter-group='sort']");
    const priceSlider = document.getElementById("priceSlider");
    const tableRows = document.querySelectorAll("table tr:nth-child(n+2)"); // Excluding the header row

    applyButton.addEventListener("click", function () {
        // Collect the filter criteria
        let selectedCuisine = getSelectedValue(cuisineButtons);
        let selectedRating = getSelectedValue(ratingButtons);
        let selectedHours = getSelectedValue(hoursButtons);
        let selectedSort = getSelectedValue(sortButtons);
        let selectedPrice = priceSlider.value;

        // Apply filters to the table
        tableRows.forEach(row => {
            let cells = row.cells;
            let cuisine = cells[1].textContent.toLowerCase();
            let rating = parseFloat(cells[7].textContent.split(" ")[0]); // Assuming rating is in the format like "4.0"
            let hours = cells[8].textContent.toLowerCase();
            let price = parseFloat(cells[2].textContent.replace(/[^0-9.]/g, "")); // Assuming price info is in cell[2]

            let matchesCuisine = selectedCuisine === "any" || cuisine.includes(selectedCuisine);
            let matchesRating = selectedRating === "any" || rating >= parseFloat(selectedRating);
            let matchesHours = selectedHours === "any" || hours.includes(selectedHours);
            let matchesPrice = price <= selectedPrice;

            // Hide or show the row based on the filter conditions
            if (matchesCuisine && matchesRating && matchesHours && matchesPrice) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }
        });

        // Apply sorting if needed
        if (selectedSort) {
            sortTable(selectedSort);
        }
    });

    // Utility to get the selected filter value from buttons
    function getSelectedValue(buttons) {
        for (let button of buttons) {
            if (button.classList.contains("selected")) {
                return button.getAttribute("data-filter-value");
            }
        }
        return "any"; // Default if none selected
    }

    // Event listeners for filter buttons
    cuisineButtons.forEach(button => {
        button.addEventListener("click", () => toggleButtonSelection(button, cuisineButtons));
    });

    ratingButtons.forEach(button => {
        button.addEventListener("click", () => toggleButtonSelection(button, ratingButtons));
    });

    hoursButtons.forEach(button => {
        button.addEventListener("click", () => toggleButtonSelection(button, hoursButtons));
    });

    sortButtons.forEach(button => {
        button.addEventListener("click", () => toggleButtonSelection(button, sortButtons));
    });

    // Utility to toggle button selection state
    function toggleButtonSelection(button, groupButtons) {
        groupButtons.forEach(b => b.classList.remove("selected"));
        button.classList.add("selected");
    }

    // Function to sort the table based on selected sort criteria
    function sortTable(sortType) {
        let sortedRows = Array.from(tableRows);
        sortedRows.sort((rowA, rowB) => {
            let cellA = rowA.cells[0].textContent.toLowerCase();
            let cellB = rowB.cells[0].textContent.toLowerCase();

            if (sortType === "distance") {
                let distanceA = parseInt(rowA.cells[3].textContent);
                let distanceB = parseInt(rowB.cells[3].textContent);
                return distanceA - distanceB;
            } else if (sortType === "relevance") {
                return cellA.localeCompare(cellB); // Default sorting by name (relevance)
            }
        });

        // Re-append sorted rows to the table
        sortedRows.forEach(row => row.parentElement.appendChild(row));
    }
});

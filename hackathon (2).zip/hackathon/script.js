document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('.button, .cuisine-button');
    const priceSlider = document.getElementById('priceSlider');
    const priceDisplay = document.querySelector('.price-range-display');
    const clearButton = document.querySelector('.clear-button');
    const applyButton = document.querySelector('.apply-button');

    // --- Button Selection Logic ---
    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const group = button.dataset.filterGroup;
            // Deselect all buttons in the same group
            document.querySelectorAll(`.button[data-filter-group='${group}'], .cuisine-button[data-filter-group='${group}']`).forEach(btn => {
                btn.classList.remove('selected');
            });
            // Select the clicked button
            button.classList.add('selected');
        });
    });

    // --- Price Slider Logic ---
    const updatePriceDisplay = () => {
        const value = parseInt(priceSlider.value);
        let displayText;
        if (value >= 100) {
            displayText = 'CA$1 - CA$100+';
        } else {
            displayText = `CA$1 - CA$${value}`;
        }
        priceDisplay.textContent = displayText;
    };

    priceSlider.addEventListener('input', updatePriceDisplay);
    // Initialize the display on page load
    updatePriceDisplay();

    // --- Clear Button Logic ---
    clearButton.addEventListener('click', () => {
        // Deselect all buttons
        buttons.forEach(btn => {
            btn.classList.remove('selected');
        });

        // Reset price slider and display
        priceSlider.value = priceSlider.min; // Reset to min value
        updatePriceDisplay();

        // Optionally, select default 'Any' or 'Relevance' buttons if they exist
        const defaultSort = document.querySelector('.button[data-filter-group="sort"][data-filter-value="relevance"]');
        if (defaultSort) defaultSort.classList.add('selected');
        const defaultRating = document.querySelector('.button[data-filter-group="rating"][data-filter-value="any"]');
        if (defaultRating) defaultRating.classList.add('selected');
        const defaultHours = document.querySelector('.button[data-filter-group="hours"][data-filter-value="any"]');
        if (defaultHours) defaultHours.classList.add('selected');
        const defaultCuisine = document.querySelector('.cuisine-button[data-filter-group="cuisine"][data-filter-value="any"]');
        if (defaultCuisine) defaultCuisine.classList.add('selected');
    });

    // --- Apply Button Logic ---
    applyButton.addEventListener('click', () => {
        const selectedFilters = {};

        // Collect selected sort
        const selectedSort = document.querySelector('.button[data-filter-group="sort"].selected');
        if (selectedSort) selectedFilters.sort = selectedSort.dataset.filterValue;

        // Collect selected price
        selectedFilters.price = parseInt(priceSlider.value);

        // Collect selected rating
        const selectedRating = document.querySelector('.button[data-filter-group="rating"].selected');
        if (selectedRating) selectedFilters.rating = selectedRating.dataset.filterValue;

        // Collect selected hours
        const selectedHours = document.querySelector('.button[data-filter-group="hours"].selected');
        if (selectedHours) selectedFilters.hours = selectedHours.dataset.filterValue;

        // Collect selected cuisine
        const selectedCuisine = document.querySelector('.cuisine-button[data-filter-group="cuisine"].selected');
        if (selectedCuisine) selectedFilters.cuisine = selectedCuisine.dataset.filterValue;

        // Collect selected more filters
        const selectedMore = document.querySelector('.button[data-filter-group="more"].selected');
        if (selectedMore) selectedFilters.more = selectedMore.dataset.filterValue;

        console.log('Applied Filters:', selectedFilters);
        // Here you would typically send these filters to a backend or update the UI
        alert('Filters applied! Check the console for details.');
    });

    // --- Initial State Setup ---
    // Ensure the 'Relevance' button is selected by default for 'Sort by'
    const defaultSortButton = document.querySelector('.button[data-filter-group="sort"][data-filter-value="relevance"]');
    if (defaultSortButton) {
        defaultSortButton.classList.add('selected');
    }
    // Ensure the 'Any' button is selected by default for 'Rating'
    const defaultRatingButton = document.querySelector('.button[data-filter-group="rating"][data-filter-value="any"]');
    if (defaultRatingButton) {
        defaultRatingButton.classList.add('selected');
    }
    // Ensure the 'Any' button is selected by default for 'Hours'
    const defaultHoursButton = document.querySelector('.button[data-filter-group="hours"][data-filter-value="any"]');
    if (defaultHoursButton) {
        defaultHoursButton.classList.add('selected');
    }
    // Ensure the 'Any' button is selected by default for 'Cuisine'
    const defaultCuisineButton = document.querySelector('.cuisine-button[data-filter-group="cuisine"][data-filter-value="any"]');
    if (defaultCuisineButton) {
        defaultCuisineButton.classList.add('selected');
    }
});
document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('filtersModal');
    const openModalButton = document.getElementById('openModal');
    const closeModalButton = document.getElementById('closeModal');

    // Open the modal
    openModalButton.addEventListener('click', () => {
        modal.style.display = 'block';
    });

    // Close the modal
    closeModalButton.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    // Close the modal when clicking outside of the modal content
    window.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});